# KXTXR VIDEO visual corpus

This directory is the browser delivery pack for the KXTXR scroll-film.

- `corpus/` contains 65 individually addressable WebP derivatives, one for every generated PNG in `/KXTXR_VIDEO`.
- `corpus-manifest.json` preserves each original filename, original dimensions and SHA-256 source identity.
- `audio/111-cinematic.mp3` is a browser delivery derivative of the true-peak-corrected archival 111 master. It is not the archival master.
- `audio-manifest.json` preserves source and derivative hashes.

The images are optimized derivatives so the scroll-film can preload and transition them without shipping ~151 MB of PNG payload on first contact.
